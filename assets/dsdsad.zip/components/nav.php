    <div class="header head__contc">
            <div class="burgr-box" id="meisa">
                <div class="meisa__logo desk">
                    <img src="https://meisamex.com.mx/assets/img/lg/meisa/22meisa879234789423.svg" alt="logo of Blogr">
                </div>
                <img src="https://meisamex.com.mx/assets/img/lg/meisa/icon-hamburger.svg" id="burgr-icon" alt="Meisa Mex" title="Meisa Mex" />
                
                <div id="burgr-menu" class="nave">
                    <div class="meisa__logo mobi">
                        <img src="https://meisamex.com.mx/assets/img/lg/meisa/22meisa879234789423.svg" alt="Meisa Mex">
                      </div>
                  <nav>
                    <ul>
                        <li>
                            <a href="https://meisamex.com.mx/" class="link__text__menu">Inicio</a>
                        </li>
                        <li>
                            <a href="https://meisamex.com.mx/" class="link__text__menu">Compra / Venta</a>
                        </li>
                        <li>
                            <div class="drpdwn-box">
                            <div class="drpdwn-btn" id="drpdwn-btn">
                                <a href="#" class="link__text__menu">Plantas de Luz</a> <span class="drpdwn-icon"><i class="fa"><img src="https://meisamex.com.mx/assets/img/lg/meisa/icon-arrow-light.svg" alt="Meisa Mex" title="Meisa Mex" /></i></span>
                            </div>
                            <div class="drpdwn">
                                <ul class="drpdwn-list">
                                <li><a href="https://meisamex.com.mx/">Venta</a></li>
                                <li><a href="https://meisamex.com.mx/">Renta</a></li>
                                </ul>
                            </div>
                            </div>
                        </li>
                        <li>
                           <a href="https://meisamex.com.mx/" class="link__text__menu">Maniobras</a>
                        </li>
                        <li>
                            <a href="https://meisamex.com.mx/Contacto/" class="link__text__menu">Contacto</a>
                        </li>
                    </ul>
                  </nav>
                  <div id="rght-nav">
                    <ul>
                      <li><a href="https://meisamex.com.mx/en/" class="big-btn solid link__text__menus">English Version</a></li>
                    </ul>
                  </div>
                </div>
            </div>
    </div>