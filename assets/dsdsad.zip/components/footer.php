            <div class="logo__foter">
              <img src="https://meisamex.com.mx/assets/img/lg/meisa/22meisa879234789423.svg" loading="lazy" alt="Meisa Mex" title="Meisa Mex">
            </div>
            <div class="head__footer">
                <h3>Contacto</h3>
                <div class="link__footer">
                    <div class="link__footer__lg">
                        <img src="https://meisamex.com.mx/assets/img/lg/foot/22loca78943879342897.svg" loading="lazy" alt="Ubicación de Meisa Mex" title="Ubicación de Meisa Mex">
                        <p>5 de mayo 20, Reforma, Delegación Santa Maria Totoltepec</p>
                    </div>
                    <div class="link__footer__lg">
                        <img src="https://meisamex.com.mx/assets/img/lg/foot/22corr98749848397902.svg" loading="lazy" alt="Contacto de Meisa Mex" title="Contacto de Meisa Mex">
                        <a href="mailto:contacto@meisa.com.mx">contacto@meisa.com.mx</a>
                    </div>
                    <div class="link__footer__lg">
                        <img src="https://meisamex.com.mx/assets/img/lg/foot/22wh9879898535454554.svg" loading="lazy" alt="Contacto de Meisa Mex" title="Contacto de Meisa Mex">
                        <a href="tel:7228283858">722 828 3858</a>
                    </div>
                    <div class="link__footer__lg">
                        <img src="https://meisamex.com.mx/assets/img/lg/foot/22wh9879898535454554.svg" loading="lazy" alt="Contacto de Meisa Mex" title="Contacto de Meisa Mex">
                        <a href="tel:5535688727">55 3568 8727</a>
                    </div>
                </div>
            </div>
            <div class="head__footer__one">
                <h3>Acera de Meisa</h3>
                <div class="link__footer">
                    <a href="https://meisamex.com.mx/">Inicio</a>
                    <a href="https://meisamex.com.mx/">Compra</a>
                    <a href="https://meisamex.com.mx/">Venta</a>
                    <a href="https://meisamex.com.mx/">Maniobras</a>
                    <a href="https://meisamex.com.mx/">Contacto</a>
                </div>
            </div>
            <div class="head__footer__two">
                <h3>Redes Socilaes</h3>
                <div class="link__social__footer">
                    <div class="link__social__red">
                        <a href="https://www.facebook.com/meisaequip">
                            <img src="https://meisamex.com.mx/assets/img/lg/foot/22fb9058305989054435.svg" loading="lazy" alt="Facebook Meisa Mex" title="Facebook Meisa Mex">
                        </a>
                        <a href="https://www.instagram.com/meisa_mex/">
                            <img src="https://meisamex.com.mx/assets/img/lg/foot/22ig8974923u432432444.svg" loading="lazy" alt="Instagram Meisa Mex" title="Instagram Meisa Mex">
                        </a>
                        <a href="https://www.linkedin.com/in/meisamex/">
                            <img src="https://meisamex.com.mx/assets/img/lg/foot/22link23498793244234232.svg" loading="lazy" alt="Linkedin Meisa Mex" title="Linkedin Meisa Mex">
                        </a>
                        <a href="https://twitter.com/meisamex">
                            <img src="https://meisamex.com.mx/assets/img/lg/foot/22tw423432344324.svg" loading="lazy" alt="Twitter Meisa Mex" title="Twitter Meisa Mex">
                        </a>
                        <a href="https://www.youtube.com/user/meisaequipos">
                            <img src="https://meisamex.com.mx/assets/img/lg/foot/22you2343478423789098234.svg" loading="lazy" alt="Youtube Meisa Mex" title="Youtube Meisa Mex">
                        </a>
                    </div>
                </div>
            </div>